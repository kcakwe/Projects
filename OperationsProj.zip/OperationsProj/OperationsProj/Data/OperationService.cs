﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OperationsProj.Data
{
    class OperationService
    {
        private string[] operaions = new string[5] { "Add", "Delete", "Update", "Select", "Sort" };

        public Task<List<Operation>> GetOperationAsync()
        {
            Random rng = new Random();
            Array types = typeof(DeviceType).GetEnumValues();
            return Task.FromResult(Enumerable.Range(1, 5).Select(index => new Operation
            {
                OperationId = index,
                Name = operaions[rng.Next(0, 5)],
                OrderInWhichToPerform = index,
                ImageData = null,
                Device = new Device()
                {
                    DeviceID = index,
                    Name = "Cannon",
                    DeviceType = (DeviceType)types.GetValue(rng.Next(types.Length))
                }
            }).ToList());
        }
    }
}
