﻿namespace OperationsProj.Data
{
    enum DeviceType
    {
        BarcodeScanner,
        Printer,
        Camera,
        SocketTray
    }
}
