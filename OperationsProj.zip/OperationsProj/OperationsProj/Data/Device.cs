﻿namespace OperationsProj.Data
{
    class Device
    {
        public int DeviceID { get; set; }
        public string Name { get; set; }
        public DeviceType DeviceType { get; set; }
    }
}
